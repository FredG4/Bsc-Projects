/**
 * 
 */
/**
 * 
 */
module CancerFinder {
	requires java.desktop;
}