package cancerfinder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.List;
import cancerfinder.Amostra;
import cancerfinder.Grafo;
import cancerfinder.RedeBayes;



public class Aplicação2 implements Serializable{
    Grafo grafo;
	private JFrame frame;
	private RedeBayes rede;
	private Amostra  am;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aplicação2 window = new Aplicação2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Aplicação2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setForeground(new Color(181, 202, 197));
		frame.setBackground(new Color(181, 202, 197));
		frame.setBounds(100, 100, 940, 501);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 0, 0);
        frame.getContentPane().add(panel);
        panel.setForeground(UIManager.getColor("Button.highlight"));
        panel.setBackground(UIManager.getColor("Button.disabledShadow"));
        frame.getContentPane().add(panel);
        placeComponents(panel);
        panel.setLayout(null);
        

        JButton Classificador = new JButton("Classificar Amostra");
		Classificador.setFont(new Font("Dialog", Font.BOLD, 30));
		Classificador.setBounds(245, 264, 378, 102);
		frame.getContentPane().add(Classificador);
		Classificador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                classificar();
            }
        });
        
        
		JButton CarregarRede = new JButton("Carregar Rede de Bayes");
		CarregarRede.setForeground(new Color(0, 0, 0));
		CarregarRede.setBackground(UIManager.getColor("Button.background"));
		CarregarRede.setFont(new Font("Dialog", Font.BOLD, 20));
		CarregarRede.setBounds(245, 116, 378, 102);
		frame.getContentPane().add(CarregarRede);
		CarregarRede.addActionListener(new ActionListener() {
      	@Override
      	public void actionPerformed(ActionEvent e) {
          	CarregarRede();
      	}
  	});
	}
	
	private void placeComponents(JPanel panel) {
	}	
	
	
	private void CarregarRede() {
	    JFileChooser fileChooser = new JFileChooser();
	    int result = fileChooser.showOpenDialog(frame);

	    if (result == JFileChooser.APPROVE_OPTION) {
	        File selectedFile = fileChooser.getSelectedFile();

	        try (FileInputStream fileInputStream = new FileInputStream(selectedFile);
	             ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {

	        	Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
	        	this.rede = (RedeBayes) objectInputStream.readObject();	  


	        } catch (Exception  e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Erro a carregar a Rede Bayesiana", "Erro", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}

	private void classificar() {
		String parametros = JOptionPane.showInputDialog("Submeta os parametros:");
		
		if (parametros == null) {
	        System.out.println("Cancelada pelo utilizador");
	        return;
	    }
		String[] stringParametros = parametros.split(",");
		if (stringParametros.length != rede.parametros()) {
	        System.out.println("Erro: número incorreto de parametros");
	        return;
	    }

	    int[] para = new int[stringParametros.length];
	    for (int i = 0; i < stringParametros.length; i++) {
	        try {
	            para[i] = Integer.parseInt(stringParametros[i]);
	        } catch (NumberFormatException e) {
	            System.out.println("Erro: formato inválido de parametros");
	            return;
	        }
	    }

	    String classificacao = rede.diagnostico(am,para);

	    if (classificacao != null) {
	        JOptionPane.showMessageDialog(null, "A amostra foi classificada como: " + classificacao);
	    } else {
	        System.out.println("Erro: Classificação Bayesiana não acessível");
	    }
	}

}
