package cancerfinder;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class Amostra implements Serializable {
  private ArrayList<int []> lista;
  private int [] domain = null;

  public Amostra() {
    this.lista = new ArrayList<int []>();
  }

  static int [] convert (String line) {
    String cvsSplitBy = ",";
    String[] strings     = line.split(cvsSplitBy);
    int[] stringToIntVec = new int[strings.length];
    for (int i = 0; i < strings.length; i++)
      stringToIntVec[i] = Integer.parseInt(strings[i]);
    return stringToIntVec;
    }

  public Amostra(String csvFile) {
    this.lista = new ArrayList<int []>();;
    this.domain = null;
    BufferedReader br = null;
    String line = "";


    try {br = new BufferedReader(new FileReader(csvFile));
      while ((line = br.readLine()) != null) {	
        add(convert(line));
      }

    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      if (br != null) {
        try {
          br.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
  }

  public void add (int[] v){ 
		if (domain == null) {
			domain = Arrays.copyOf(v, v.length);
		} else {
			for (int i=0; i<v.length; i++) {
				domain[i] = Math.max(domain[i], v[i]);
			}			
		}
		lista.add(v);
	}

  public int length (){
    return lista.size();
  }

  public int [] element (int i){
    return lista.get(i);
  }



	public int count(int[] var, int[] val){ 
		int r=0;
		for (int[] entry : lista) {
			boolean match = true;
			for (int i = 0; i<var.length; i++) {
				int variableIndex = var[i];
				int expectedValue = val[i];
				if (entry[variableIndex] != expectedValue) {
					match = false;
				}
			}
			if (match) {
				r++;
			}
		}
			return r;
	}


  public int domain (int var[]){ 
		int r=1;
		for (int i=0; i<var.length; i++) {
			int j = var[i];
			r=r*(domain[j]+1);
			
		}
		return r;
	}

  @Override
  public String toString() {
    String s="\n[\n";
    if (lista.size()>0) s+=Arrays.toString(lista.get(0));
    for (int i=1; i<lista.size();i++)
      s+="\n"+Arrays.toString(lista.get(i));
    s+="\n]";

    return "Amostra " + s;
  }

    
  public int[] getDomain() {
	return domain;
  }

//  public static void main(String[] args) {
//    Amostra amostra = new Amostra("bcancer.csv");
//    System.out.println(amostra);
//    }
}
    
    