package cancerfinder;

import java.io.Serializable;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Stack;
import cancerfinder.Amostra;
import cancerfinder.Grafo;

public class RedeBayes implements Serializable {
    Grafo grafo;
    double s = 0.5;
    private LinkedHashMap<String, Double> Rede;


    public RedeBayes(Amostra am, Grafo grafo, double s) {
        this.grafo = grafo;
        this.s = s;
        this.Rede = new LinkedHashMap<>();
        ConstrutorRede(am);
    }
    
    private void ConstrutorRede (Amostra am) {
    	int comp = am.getDomain().length-1;
    	int [] Dominio = am.getDomain();
    	for (int nod=0; nod < comp; nod++) {
    		LinkedList<Integer> pais = grafo.paiscomclasse(nod);
    		int npais = pais.size();
    		int [] valpais = new int [npais];
    		for (int valnod=0; valnod <= Dominio[nod]; valnod++) {
    			if (npais==3) {
					int p1 = pais.get(0);
					int p2 = pais.get(1);
					int p3 = pais.get(2);
					for (int val_p1 = 0; val_p1<=Dominio[p1]; val_p1++) {
						  for (int val_p2 = 0; val_p2<=Dominio[p2]; val_p2++) {
							  for (int val_p3 = 0; val_p3<=Dominio[p3]; val_p3++) {
								  valpais[0]=val_p1;
								  valpais[1]=val_p2;
								  valpais[2]=val_p3;
								  String key = getKey(nod,valnod,valpais);
								  Rede.put(key,DFO(am,nod,valnod,valpais));
						   }
						}	  
					}
				}
    			if (npais==2) {
					int p1 = pais.get(0);
					int p2 = pais.get(1);
					for (int val_p1 = 0; val_p1<=Dominio[p1]; val_p1++) {
						  for (int val_p2 = 0; val_p2<=Dominio[p2]; val_p2++) {
							  valpais[0]=val_p1;
							  valpais[1]=val_p2;
			    			  String key = getKey(nod,valnod,valpais);
							  Rede.put(key,DFO(am,nod,valnod,valpais));
						  }
						
					}
				}
    			
				if (npais==1) {
					int p1 = pais.get(0);
					for (int val_p1 = 0; val_p1<=Dominio[p1]; val_p1++) {
						valpais[0]=val_p1;
	    				String key = getKey(nod,valnod,valpais);
						Rede.put(key,DFO(am,nod,valnod,valpais));
					}
				}
				
    			if (npais==0) {
    				String key = getKey(nod,valnod,valpais);
					Rede.put(key,DFO(am,nod,valnod,valpais));
    			}
    		}
    	}
    }
    
    
    public void printRede() {
        for (Entry<String, Double> entry : Rede.entrySet()) {
            String key = entry.getKey();
            Double value = entry.getValue();
            System.out.println(key+"; DFO="+value);
        }
    }

	
	
    public double DFO (Amostra am, int nod, int valnod, int [] valpais) {
        int npais = valpais.length;
        int [] vals = new int [npais+1];
        int [] vars = new int [npais+1];
        int [] pais = grafo.convertToIntArray(grafo.paiscomclasse(nod));

        for (int i=0; i < npais; i++) {
            vars[i]= pais [i];
            vals[i]= valpais[i];
        }

        vals[npais]= valnod;
        vars[npais]= nod;

        double contagem_fp = am.count(vars, vals);
        double contagem_p = am.count(pais, valpais);
        double dominio_nod = am.domain(new int [] {nod});

        double DFO = (contagem_fp + s)/(contagem_p+(s*dominio_nod));

        return DFO;
    }
    
    public double probabilidadeCondicionada (Amostra am, int [] vetor) {
    	double p = 1;
    	int len = vetor.length;
    	int comp = am.getDomain().length-1;
    	double Pr_c = am.count(new int [] {comp}, new int [] {vetor[len-1]});
    	for (int nod = 0; nod < vetor.length-1; nod++) {
    		int val_nod = vetor[nod];
    		LinkedList <Integer> pais = grafo.paiscomclasse(nod);
    		int npais = pais.size();
    		int [] valpais = new int [npais];
    		
    		for (int i = 0; i < npais; i++) {
    			valpais[i] = vetor[pais.get(i)];
    		}
    		String key = getKey(nod, val_nod, valpais);
    		double prob = this.Rede.get(key);
    		p *= prob;
    		
    	}
    	return Pr_c * p;
    }


    public double[] probnormal(Amostra am, int[] vetorsemclasse) {
        int classe = vetorsemclasse.length;
        int dominioclasse = am.getDomain()[classe];
        double[] probconds = new double[dominioclasse+1];
        double normalizacao = 0;
        int[] vetor2 = new int [classe+1];
        for (int i=0; i<classe; i++) {
        	vetor2[i]=vetorsemclasse[i];
        }

        for (int val_c = 0; val_c <= dominioclasse; val_c++) {
            vetor2[classe] = val_c;
            double probcond = probabilidadeCondicionada(am, vetor2);
            probconds[val_c] = probcond;
            normalizacao += probcond;
        }
        //System.out.println(Arrays.toString(probconds));

        if (normalizacao != 0) {
            for (int i = 0; i <= dominioclasse; i++) {
                probconds[i] /= normalizacao;
            }
        }
        System.out.println(Arrays.toString(probconds));

        return probconds;
    }
    
    public void printProbVetor (Amostra am, int [] vetor) {
    	int comp = vetor.length-1;
    	int classe = vetor[comp];
    	int [] vetor2 = new int [vetor.length-1];
    	for (int i=0; i<vetor2.length; i++) {
    		vetor2[i]=vetor[i];
    	}
        double[] probfinal = probnormal(am, vetor2);

        String Vetor = Arrays.toString(vetor);
        Double ProbFinal = probfinal[classe];

        System.out.println("am: " + Vetor + " prob: " + ProbFinal);
    }
    
    
    private String getKey (int nod, int valnod, int[] valpais) {
    	return "nod="+nod+", valnod="+valnod+", pais="+grafo.paiscomclasse(nod)+", valpais="+Arrays.toString(valpais);
	}
  
	public int parametros() {
		return this.grafo.dim;
	}
	
	public String diagnostico (Amostra am, int [] vetor) {
		int [] vetor2 = new int [vetor.length-1];
		for (int i=0; i<vetor.length-1; i++) {
			vetor2[i]=vetor[i];
		}
		double [] dias = probnormal(am, vetor2);
		if (dias [0] < 0.5) {
			return "Maligno (certeza:"+ dias[1]+")";
		}
		else {
			return "Beningno (certeza:"+ dias[0]+")";
		}
	}
    
    
//    public static void main(String[] args) {
//    	
//		Amostra am = new Amostra("bcancer.csv");
//		Grafo go= new Grafo(11);
//		for(int i=0; i<10;i++) go.addEdge(10, i);
//		
//		go.addEdge(3,2);
//		go.addEdge(5,2);
//		go.addEdge(5,3);
//		go.addEdge(6,4);
//		
//		RedeBayes BN = new RedeBayes(am, go, 0.5);
//		int[] w= {1, 0, 2, 0, 0, 0, 0, 2, 1, 1, 0};
//		BN.printProbVetor(am,w);
//	}
}
