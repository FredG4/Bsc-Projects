package cancerfinder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import cancerfinder.Amostra;


public class Grafo implements Serializable{
	  int dim;
	  LinkedList<Integer> filhos[];


	  public Grafo (int dim) {
	    super();
	    this.dim = dim;
	    this.filhos = new LinkedList[dim];
	    for (int i = 0; i < filhos.length; i++) {
	      filhos[i] = new LinkedList<Integer> ();
	    }
	  }

	  public double log2(double x) {
		        double log2 = Math.log(x) / Math.log(2);
		        return log2;
		    }


	  public void addEdge (int nod1, int nod2) {
	    if (! filhos[nod1].contains(nod2)) filhos[nod1].add(nod2);
	  }

	  public void removeEdge (int nod1, int nod2) {
	    if (filhos[nod1].contains(nod2)) filhos[nod1].remove(filhos[nod1].indexOf(nod2));
	  }

	  public boolean edgeQ (int nod1, int nod2) {
	    return filhos[nod1].contains(nod2);
	  }

	  public void invertEdge (int nod1, int nod2) {
	    if ( edgeQ(nod1,nod2) != edgeQ (nod2,nod1) ) {
	      if (edgeQ (nod1,nod2)) {
	        removeEdge (nod1,nod2);
	        addEdge (nod2,nod1);
	      }
	      else {
	        removeEdge (nod2,nod1);
	        addEdge (nod1,nod2);	
	      }
	    }
	  }


	  public LinkedList <Integer> parents(int nod) {
	    LinkedList <Integer > pais = new LinkedList <Integer> ();
	    for (int i = 0; i < filhos.length-1; i++) {
	      if (filhos[i].contains(nod)){
	        pais.add(i);
	      }
	    }
	    return pais;
	  }
	  
	  
	  public LinkedList <Integer> paiscomclasse(int nod) {
		    LinkedList <Integer > pais = parents(nod);
		    pais.addFirst(filhos.length-1);
		        return pais;
		  }


	  public LinkedList <Integer> BFS (int nod) {
	    LinkedList<Integer> visited = new LinkedList<Integer>();
	    Queue<Integer> q = new LinkedList<Integer> ();
	    q.addAll(filhos[nod]);
	    while (! q.isEmpty()) {
	      int n = q.remove ();
	      if (! visited.contains(n)) {
	        visited.add(n);
	        q.addAll(filhos[n]);
	      }
	    }
	    return visited;
	  }


	  public boolean connected (int nod1, int nod2) {
	    return (BFS(nod1).contains(nod2));
	  }

	  public double it(int nod, Amostra am) {
		  LinkedList<Integer> pais = parents(nod);
		  int npais = pais.size();
		  int m = am.length();
		  int comp = am.getDomain().length-1;
		  int [] Dominio = am.getDomain();
		  double It_final = 0;
		  if (npais == 2) {
			  int p1 = pais.get(0);
			  int p2 = pais.get(1);
			  
			  for (int alfa = 0; alfa<=Dominio[nod]; alfa++) {
				  for (int val_p1 = 0; val_p1<=Dominio[p1]; val_p1++) {
					  for (int val_p2 = 0; val_p2<=Dominio[p2]; val_p2++) {
						  for (int val_class = 0; val_class<=Dominio[comp]; val_class++) {
							  double Prt_c = am.count(new int [] {comp}, new int [] {val_class});
							  double Prt_dc = am.count(new int [] {nod, comp}, new int [] {alfa, val_class});
							  double Prt_wc = am.count(new int [] {p1, p2, comp}, new int [] {val_p1, val_p2, val_class});
							  double Prt_dwc = am.count(new int [] {nod, p1, p2, comp}, new int [] {alfa, val_p1, val_p2, val_class});
							  
							  if ((Prt_dwc*Prt_c*Prt_dc*Prt_wc) != 0) {
								  It_final += ((Prt_dwc/m)*log2((Prt_dwc*Prt_c)/(Prt_dc*Prt_wc)));
							  }
						  }
					  }
				  }
			  }
		  }
		  if (npais == 1) {
			  int p1 = pais.get(0);
			  
			  for (int alfa = 0; alfa<=Dominio[nod]; alfa++) {
				  for (int val_p1 = 0; val_p1<=Dominio[p1]; val_p1++) {
					  for (int val_class = 0; val_class<=Dominio[comp]; val_class++) {
						  double Prt_c = am.count(new int [] {comp}, new int [] {val_class});
						  double Prt_dc = am.count(new int [] {nod, comp}, new int [] {alfa, val_class});
						  double Prt_wc = am.count(new int [] {p1, comp}, new int [] {val_p1, val_class});
						  double Prt_dwc = am.count(new int [] {nod, p1, comp}, new int [] {alfa, val_p1, val_class});
						  
						  if ((Prt_dwc*Prt_c*Prt_dc*Prt_wc) != 0) {
							  It_final += ((Prt_dwc/m)*log2((Prt_dwc*Prt_c)/(Prt_dc*Prt_wc)));
						  }
					  }
				  }
			  }
		  }
		  if (npais == 0) {
			  It_final += 0;
			  }
		  
		  
		  return It_final;	  
	  }


	  public double theta (Amostra am) {
	      double sum = 0;

	      double Dc = am.domain(new int [] {am.getDomain().length-1});

	      double parcela_1 = Dc - 1;

	      for (int i = 0; i<am.getDomain().length-1; i++) {
	          LinkedList<Integer> pais = parents (i);
	          int [] Dominio = am.getDomain();
	          sum += (Dominio[i])*(am.domain(convertToIntArray(pais))*Dc);
	      }

	      double theta_final = parcela_1 + sum;
	      return theta_final;
	  }
		
		public double MDL (Amostra am) {
			double m = am.length();
			double parcela1 = ((log2(m))/2)*theta(am);
			
			double somat = 0;
			double compvars = am.getDomain().length - 1;
			for (int  i=0; i<compvars; i++) {
				somat += it(i,am);
		  }
			double parcela2 = m*somat;

			return parcela1-parcela2;
	}

		
		public double MDLdelta (Amostra am, int nod1, int nod2, int oper) {
			double MDLoriginal = this.MDL(am);
		    double MDLalterado = alterar(nod1, nod2, oper).MDL(am);
		    return MDLoriginal-MDLalterado;
		}


	  	public Grafo clonar () {
	  		Grafo novoGrafo = new Grafo(dim);

	        for (int i = 0; i < dim; i++) {
	            for (Integer vertice : filhos[i]) {
	                novoGrafo.filhos[i].addLast(vertice);
	            }
	        }
	        return novoGrafo;
	  	}
	  
		public Grafo alterar (int nod1, int nod2, int oper) {
			Grafo alterada = this.clonar();
		    if (oper == 0) {
		        alterada.removeEdge(nod1, nod2);
		        return alterada;
		    } else if (oper == 1) {
		        alterada.addEdge(nod1, nod2);
		        return alterada;
		    } else if (oper == 2) {
		        alterada.invertEdge(nod1, nod2);
		        return alterada;
		    } else {
		        throw new RuntimeException("This operation does not exist");
		    }
		}


		public int[] convertToIntArray (LinkedList<Integer> linkedlist) {
				int tamanho = linkedlist.size();
		        int[] array = new int[tamanho];
		        for (int i=0; i<tamanho; i++) {
		        	array[i]=linkedlist.get(i);
		        }
		        return array;
		    }
		
		
	  public String toString() {
	    return "Grafo [dim=" + dim + ", a=" + Arrays.toString(filhos) + "]";
	  }


//  public static void main (String[] args) {
//    Grafo go = new Grafo(11);
//    Amostra am = new Amostra("bcancer.csv");
//
//    for(int i=0; i<10;i++) go.addEdge(10, i);
//
//    go.addEdge(3, 2);
//
//    go.addEdge(5, 2);
//
//    go.addEdge(5, 3);
//
//    go.addEdge(6, 4);
//
//    
//    
//    System.out.println(go.parents(3));
//    System.out.println(go.it(2, am));
//    System.out.println(go.it(3, am));
//    System.out.println(go.it(4, am));
//    System.out.println(go.MDL(am));   
//  }
}
