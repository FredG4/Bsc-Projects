package cancerfinder;

import java.awt.EventQueue;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import cancerfinder.Amostra;
import cancerfinder.Grafo;
import cancerfinder.RedeBayes;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Aplicação1 implements Serializable {
	private JFrame frame;
	private Grafo GrafoOficial;
	private Amostra AmostraOficial;
	private int PoolNumber = 5;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Aplicação1 window = new Aplicação1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Aplicação1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setForeground(new Color(181, 202, 197));
		frame.setBackground(new Color(181, 202, 197));
		frame.setBounds(100, 100, 940, 501);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton Carregar = new JButton("Carregar Dados");
		Carregar.setForeground(new Color(0, 0, 0));
		Carregar.setBackground(UIManager.getColor("Button.background"));
		Carregar.setFont(new Font("Dialog", Font.BOLD, 30));
		Carregar.setBounds(245, 54, 378, 102);
		frame.getContentPane().add(Carregar);
		Carregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                chooseSample();
            }
        });
		
		JButton Guardar = new JButton("Guardar a Rede criada");
        Guardar.setFont(new Font("Dialog", Font.BOLD, 30));
        Guardar.setBounds(245, 166, 378, 102);
        frame.getContentPane().add(Guardar);
        Guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call your function or perform an action here
                PoolNumber = Integer.valueOf(textField.getText());
                AprenderBayes(AmostraOficial);
            }
        });
		
		textField = new JTextField();
		textField.setFont(new Font("Dialog", Font.BOLD, 50));
		textField.setBounds(245, 346, 378, 61);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		textField.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        try {
		            PoolNumber = Integer.parseInt(textField.getText());
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(frame, "Submeta um número", "Erro", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		});
		
		JLabel lblNewLabel = new JLabel("Número de grafos aleatórios");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel.setBackground(UIManager.getColor("Button.darkShadow"));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(245, 302, 379, 44);
		frame.getContentPane().add(lblNewLabel);
		

	}
	
	
	
	
	public static LinkedList<int[]> ListaAlts (Grafo grafo, Amostra am) {
		LinkedList<int[]> Alts = new LinkedList<int[]> ();
		int [] alt = new int [3];
		for (int nod1 = 0; nod1 < grafo.dim; nod1++) {
			for (int nod2 = 0; nod2 < grafo.dim; nod2++) {
				if (nod1!=nod2) {
					if (grafo.parents(nod2).contains(nod1)) {
						if (grafo.MDLdelta(am, nod1, nod2, 0) > 0.0) {
							alt [0] = nod1;
							alt [1] = nod2;
							alt [2] = 0;
							Alts.addLast(alt);
						}
						if (grafo.MDLdelta(am, nod1, nod2, 1) > 0.0) {
							alt [0] = nod1;
							alt [1] = nod2;
							alt [2] = 0;
							Alts.addLast(alt);
						}
					}
					else {
						if (grafo.MDLdelta(am, nod1, nod2, 2) > 0.0) {
							alt [0] = nod1;
							alt [1] = nod2;
							alt [2] = 0;
							Alts.addLast(alt);
						}
					}
				}
				
			}
		}
		return Alts;
	}
	
	private static void AplicarAlts (Grafo grafo, int[] alts) {
		int nod1 = alts[0];
		int nod2 = alts[1];
		
		if (alts[2]==0) {
			grafo.removeEdge(nod1, nod2);
		}
		else if (alts[2]==1) {
			grafo.invertEdge(nod1, nod2);
		}
		else if (alts[2]==2) {
			grafo.addEdge(nod1, nod2);
		}
	}
	
	
	public static void OtimizacaoMDL (Grafo grafo, Amostra am) {
		LinkedList<int[]> AltPossivel = ListaAlts (grafo, am);
		double melhorScore = Double.POSITIVE_INFINITY;
		int [] melhorAlt = null;
		
		for (int i=0; i<AltPossivel.size(); i++) {
			Grafo copia = new Grafo(grafo.dim);
			AplicarAlts(copia, AltPossivel.get(i));
			double score = copia.MDL(am);
			
			if (score < melhorScore) {
				melhorScore = score;
				melhorAlt = AltPossivel.get(i);
			}
		}
		if (melhorAlt != null) {
			AplicarAlts(grafo, melhorAlt);
		}
	}
	
	public static void Travao (Grafo grafo, Amostra am) {
		double melhorScore = 0;
		while (melhorScore != grafo.MDL(am)) {
			melhorScore = grafo.MDL(am);
			OtimizacaoMDL (grafo, am);
		}
	}
	
	
	private Grafo GrafoDesconexo (Amostra am) {
		int dim = am.getDomain().length;
		Grafo grafod = new Grafo (dim);
		for (int i=0; i<dim; i++) {
			grafod.addEdge(dim-1, i);
		}
		return grafod;
	}
	
	
	private Grafo GrafoAleatorio (Amostra am) {
		int dim = am.getDomain().length;
		Random random = new Random();
		Grafo grafoa = new Grafo (dim);
		
		for (int i=0; i<dim; i++) {
			int Edges = random.nextInt(2)+1;
			for (int j=0; j<Edges; j++) {
				int pai = random.nextInt(dim);
				grafoa.addEdge(pai, i);
			}
		}
		for (int i=0; i<dim; i++) {
			grafoa.removeEdge(i,dim-1);
		}
		for (int i=0; i<dim; i++) {
			grafoa.addEdge(dim-1, i);
		}
		return grafoa;
	}
	
	
	private RedeBayes AprenderBayes(Amostra am) {
		List <Grafo> grafos = new ArrayList<>();
		Grafo grafod = GrafoDesconexo(am);
		Travao(grafod, am);
		grafos.add(grafod);
		for (int i=0; i<PoolNumber-1; i++) {
			Grafo grafoa = GrafoAleatorio(am);
			Travao(grafoa, am);
			grafos.add(grafoa);
		}
		Grafo melhor = null;
		double melhorScore = Double.POSITIVE_INFINITY;
		for (int i=0; i<PoolNumber; i++) {
			double score = grafos.get(i).MDL(am);
			if (score < melhorScore) {
				melhorScore = score;
				melhor = grafos.get(i);
			}
		}
		GrafoOficial = melhor;
		RedeBayes RedeOficial = new RedeBayes (am, GrafoOficial, 0.5);
		return RedeOficial;
	}
	
	private void chooseSample() {
	    JFileChooser fileChooser = new JFileChooser();
	    int result = fileChooser.showOpenDialog(frame);

	    if (result == JFileChooser.APPROVE_OPTION) {
	        File selectedFile = fileChooser.getSelectedFile();
	        AmostraOficial = new Amostra(selectedFile.getAbsolutePath());
	    }
	}
	
	private void saveLearnedNetwork(RedeBayes rede) {
	    JFileChooser fc = new JFileChooser();
	    int returnValue = fc.showSaveDialog(null);
	    if (returnValue == JFileChooser.APPROVE_OPTION) {
	        File fileToSave = fc.getSelectedFile();
	        try (FileOutputStream fileOutputStream = new FileOutputStream(fileToSave);
	             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {

	            objectOutputStream.writeObject(rede);
	            JOptionPane.showMessageDialog(null, "Learned Bayesian Network saved to disk.", "Success", JOptionPane.INFORMATION_MESSAGE);

	        } catch (IOException e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error saving Bayesian Network.", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}
}
